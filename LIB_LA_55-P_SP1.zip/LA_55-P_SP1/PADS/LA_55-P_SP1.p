*PADS-LIBRARY-PART-TYPES-V9*

LA_55-P_SP1 LA55PSP1 I ANA 7 1 0 0 0
TIMESTAMP 2026.05.24.18.08.09
"element14 Part Number" 
"element14 Price/Stock" 
"Manufacturer_Name" LEM
"Manufacturer_Part_Number" LA 55-P/SP1
"Description" Current Transducer
"Datasheet Link" 
"Geometry.Height" 27mm
GATE 1 3 0
LA_55-P_SP1
1 0 U OV
2 0 U -VC
3 0 U +VC

*END*
*REMARK* SamacSys ECAD Model
258475/2067606/2.50/3/4/Integrated Circuit
