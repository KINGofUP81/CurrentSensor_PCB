*PADS-LIBRARY-PART-TYPES-V9*

TL084CN DIP794W53P254L1930H508Q14N I ANA 7 1 0 0 0
TIMESTAMP 2026.06.12.19.39.56
"Mouser Part Number" 595-TL084CN
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TL084CN?qs=q2XTDbzbm6ANF36GVAxPiQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TL084CN
"Description" Quad High Slew Rate JFET-Input Operational Amplifier
"Datasheet Link" http://www.ti.com/lit/gpn/tl084
"Geometry.Height" 5.08mm
GATE 1 14 0
TL084CN
1 0 S 1OUT
2 0 L 1IN-
3 0 L 1IN+
4 0 P VCC+
5 0 L 2IN+
6 0 L 2IN-
7 0 S 2OUT
8 0 S 3OUT
9 0 L 3IN-
10 0 L 3IN+
11 0 P VCC-
12 0 L 4IN+
13 0 L 4IN-
14 0 S 4OUT

*END*
*REMARK* SamacSys ECAD Model
182342/2067606/2.50/14/3/Integrated Circuit
