*PADS-LIBRARY-PART-TYPES-V9*

1N4007S DIOAD1470W65L470D250 I DIO 6 1 0 0 0
TIMESTAMP 2026.07.11.11.02.45
"Mouser Part Number" N/A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Taiwan-Semiconductor/1N4007S?qs=tHU%2FlV7kTySzKYFlWk%2F8oQ%3D%3D
"Manufacturer_Name" Taiwan Semiconductor
"Manufacturer_Part_Number" 1N4007S
"Description" Rectifiers 1A,1000V,Std SILASTIC Rect
"Datasheet Link" https://chawlaelectronic.com/wp-content/uploads/2020/11/1N4007S.pdf
GATE 1 2 0
1N4007S
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
644714/2067606/2.50/2/3/Diode
